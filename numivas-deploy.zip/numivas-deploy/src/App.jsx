import { useState } from "react";

// ═══════════════════════════════════════════════════════
//  NUMIVAS - Luxury Coin Collection Gallery
//  Bold aesthetic: Museum luxury with dramatic depth
// ═══════════════════════════════════════════════════════

const I = {
  Vault: () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="12" cy="12" r="3"/></svg>,
  Display: () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8m-4-4v4"/></svg>,
  Shop: () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M6 2L3 7v13a2 2 0 002 2h14a2 2 0 002-2V7l-3-5z"/><path d="M3 7h18M16 11a4 4 0 01-8 0"/></svg>,
  Help: () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3M12 17h.01"/></svg>,
  Hunt: () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>,
  External: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6m4-3h6v6m-11 5L21 3"/></svg>,
  Phone: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>,
  Location: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>,
  Link: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>,
  Bell: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"/></svg>,
  QR: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="2" y="2" width="8" height="8" rx="1"/><rect x="14" y="2" width="8" height="8" rx="1"/><rect x="2" y="14" width="8" height="8" rx="1"/><rect x="14" y="14" width="4" height="4"/></svg>,
  Compass: () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>,
  Sparkles: () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3zM19 16l.75 2.25L22 19l-2.25.75L19 22l-.75-2.25L16 19l2.25-.75L19 16z"/></svg>,
};

const COINS = [
  { id: "c1", name: "1921 Morgan Silver Dollar", year: 1921, mint: "Philadelphia", grade: "MS-65", value: 485, img: "https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=800&q=80" },
  { id: "c2", name: "1955 Double Die Lincoln Cent", year: 1955, mint: "Philadelphia", grade: "AU-58", value: 1850, img: "https://images.unsplash.com/photo-1621416894188-1c1c4f9f8b91?w=800&q=80" },
  { id: "c3", name: "2006 Gold Eagle 1oz", year: 2006, mint: "West Point", grade: "PF-70", value: 2340, img: "https://images.unsplash.com/photo-1610375461246-83df859d849d?w=800&q=80" },
  { id: "c4", name: "1893-S Morgan Dollar", year: 1893, mint: "San Francisco", grade: "VF-30", value: 5200, img: "https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=800&q=80" },
];

const PRINTS = [
  { id: "p1", name: "Eagle's Vigil", artist: "Elena Voss", edition: "42/200", nft: false, img: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=800&q=80" },
  { id: "p2", name: "The Voyage", artist: "Marcus Chen", edition: "15/150", nft: false, img: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=800&q=80" },
  { id: "p3", name: "One Giant Leap", artist: "Sofia Albrecht", edition: "NFT #0087", nft: true, img: "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=800&q=80" },
  { id: "p4", name: "Raising the Standard", artist: "James Okoro", edition: "NFT #0214", nft: true, img: "https://images.unsplash.com/photo-1634178189328-f325f504e473?w=800&q=80" },
];

const MY_DISPLAYS = [
  {
    id: "d1",
    name: "The Morgan Legacy",
    frame: "Vault Edition",
    coins: [COINS[0], COINS[3], COINS[1]],
    location: "Living Room",
    story: "Three generations of Morgan dollars, anchored by my grandfather's 1893-S — the coin that started it all.",
    img: "https://images.unsplash.com/photo-1582582621959-48d27397dc69?w=1200&q=90",
  },
  {
    id: "d2",
    name: "Gold Eagle Collection",
    frame: "Collector Secure",
    coins: [COINS[2]],
    location: "Office",
    story: "Celebrating American craftsmanship in gold.",
    img: "https://images.unsplash.com/photo-1544216717-3bbf52512659?w=1200&q=90",
  },
];

const DEFAULT_FRAMES_IMG = "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=1400&q=90";

export default function NumivasApp() {
  const [tab, setTab] = useState("displays");
  const [vaultView, setVaultView] = useState("coins");
  const [gapAlerts, setGapAlerts] = useState([
    { series: "Morgan Dollar (1878-1921)", alertOn: true, missing: ["1879-CC", "1889-CC", "1895 (Proof)"] },
    { series: "Mercury Dime (1916-1945)", alertOn: false, missing: ["1916-D", "1942/41", "1942/41-D"] },
  ]);

  const toggleAlert = (idx) => {
    setGapAlerts(prev => prev.map((item, i) => i === idx ? { ...item, alertOn: !item.alertOn } : item));
  };

  const openStore = () => window.open('https://numivas.com/shop', '_blank');

  const c = {
    bg: '#0a0a0a',
    card: '#111111',
    cardHover: '#1a1a1a',
    text: '#f5f5f5',
    textSec: '#999',
    gold: '#d4af37',
    goldDark: '#b8941f',
    goldLight: '#f0d98d',
    border: 'rgba(212, 175, 55, 0.15)',
    borderBright: 'rgba(212, 175, 55, 0.3)',
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: `
        radial-gradient(circle at 20% 20%, rgba(212, 175, 55, 0.05) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(212, 175, 55, 0.03) 0%, transparent 50%),
        linear-gradient(180deg, ${c.bg} 0%, #050505 100%)
      `,
      color: c.text,
      fontFamily: '"Cormorant Garamond", "Playfair Display", Georgia, serif',
    }}>
      {/* Animated header */}
      <header style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        background: 'rgba(10, 10, 10, 0.92)',
        backdropFilter: 'blur(30px) saturate(180%)',
        borderBottom: `1px solid ${c.border}`,
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6), 0 0 80px rgba(212, 175, 55, 0.08)',
      }}>
        <div style={{
          maxWidth: '1400px',
          margin: '0 auto',
          padding: '20px 32px',
          display: 'flex',
          alignItems: 'center',
          gap: '16px',
        }}>
          <div style={{
            width: '44px',
            height: '44px',
            borderRadius: '12px',
            background: `linear-gradient(135deg, ${c.gold}, ${c.goldDark})`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '22px',
            boxShadow: `0 8px 24px rgba(212, 175, 55, 0.35), inset 0 1px 2px rgba(255,255,255,0.2)`,
            animation: 'gentle-float 4s ease-in-out infinite',
          }}>
            💎
          </div>
          <h1 style={{
            fontSize: '32px',
            fontWeight: 500,
            letterSpacing: '1px',
            margin: 0,
            background: `linear-gradient(135deg, ${c.goldLight}, ${c.gold})`,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            textShadow: '0 0 40px rgba(212, 175, 55, 0.3)',
          }}>
            NUMIVAS
          </h1>
        </div>
      </header>

      {/* Navigation */}
      <nav style={{
        position: 'sticky',
        top: '84px',
        zIndex: 99,
        background: 'rgba(10, 10, 10, 0.88)',
        backdropFilter: 'blur(20px)',
        borderBottom: `1px solid ${c.border}`,
      }}>
        <div style={{
          maxWidth: '1400px',
          margin: '0 auto',
          padding: '12px 24px',
          display: 'flex',
          gap: '12px',
          overflowX: 'auto',
        }}>
          {[
            { id: 'displays', label: 'Displays', icon: I.Display },
            { id: 'vault', label: 'Vault', icon: I.Vault },
            { id: 'shop', label: 'Shop', icon: I.Shop },
            { id: 'help', label: 'Help & Discover', icon: I.Help },
            { id: 'hunt', label: 'Gap Finder', icon: I.Hunt },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '6px',
                padding: '12px 24px',
                background: tab === item.id
                  ? `linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(212, 175, 55, 0.1))`
                  : 'transparent',
                border: tab === item.id ? `1px solid ${c.borderBright}` : 'none',
                borderRadius: '12px',
                color: tab === item.id ? c.gold : c.textSec,
                cursor: 'pointer',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                whiteSpace: 'nowrap',
                fontFamily: '"Cormorant Garamond", serif',
              }}
              onMouseEnter={e => {
                if (tab !== item.id) {
                  e.currentTarget.style.background = 'rgba(255, 255, 255, 0.02)';
                  e.currentTarget.style.color = c.goldLight;
                }
              }}
              onMouseLeave={e => {
                if (tab !== item.id) {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = c.textSec;
                }
              }}
            >
              <item.icon />
              <span style={{ fontSize: '13px', fontWeight: 500, letterSpacing: '0.5px' }}>{item.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Main Content */}
      <main style={{ maxWidth: '1400px', margin: '0 auto', padding: '64px 32px 120px' }}>

        {/* DISPLAYS */}
        {tab === 'displays' && (
          <div style={{ animation: 'fade-in 0.5s ease-out' }}>
            <div style={{
              marginBottom: '56px',
              padding: '48px',
              borderRadius: '28px',
              background: `
                linear-gradient(135deg, rgba(212, 175, 55, 0.12) 0%, rgba(212, 175, 55, 0.03) 100%),
                radial-gradient(circle at 80% 20%, rgba(212, 175, 55, 0.08), transparent 60%)
              `,
              border: `1px solid ${c.borderBright}`,
              position: 'relative',
              overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute',
                top: '-50%',
                right: '-20%',
                width: '600px',
                height: '600px',
                background: 'radial-gradient(circle, rgba(212, 175, 55, 0.15), transparent 70%)',
                filter: 'blur(100px)',
                animation: 'pulse-glow 8s ease-in-out infinite',
              }} />
              <div style={{ position: 'relative', zIndex: 1 }}>
                <h2 style={{
                  fontSize: '64px',
                  fontWeight: 400,
                  letterSpacing: '2px',
                  margin: '0 0 16px',
                  background: `linear-gradient(135deg, ${c.goldLight}, ${c.gold})`,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}>
                  Displays
                </h2>
                <p style={{ fontSize: '22px', color: c.textSec, margin: 0, fontStyle: 'italic' }}>
                  Museum-quality showcases for your collection
                </p>
              </div>
            </div>

            {/* Display cards */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '48px' }}>
              {MY_DISPLAYS.map((display, idx) => (
                <div
                  key={display.id}
                  style={{
                    background: c.card,
                    borderRadius: '28px',
                    overflow: 'hidden',
                    border: `1px solid ${c.border}`,
                    boxShadow: '0 12px 48px rgba(0, 0, 0, 0.6)',
                    transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
                    animation: `slide-up 0.6s ease-out ${idx * 0.1}s both`,
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.transform = 'translateY(-8px)';
                    e.currentTarget.style.boxShadow = `0 24px 64px rgba(0, 0, 0, 0.7), 0 0 0 1px ${c.borderBright}`;
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 12px 48px rgba(0, 0, 0, 0.6)';
                  }}
                >
                  <div style={{
                    width: '100%',
                    height: '480px',
                    background: `url(${display.img}) center/cover`,
                    position: 'relative',
                  }}>
                    <div style={{
                      position: 'absolute',
                      inset: 0,
                      background: 'linear-gradient(to bottom, transparent 50%, rgba(0,0,0,0.7) 100%)',
                    }} />
                  </div>

                  <div style={{ padding: '48px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
                      <div>
                        <div style={{
                          display: 'inline-block',
                          padding: '6px 16px',
                          background: `linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(212, 175, 55, 0.1))`,
                          borderRadius: '8px',
                          fontSize: '12px',
                          fontWeight: 600,
                          color: c.gold,
                          marginBottom: '16px',
                          textTransform: 'uppercase',
                          letterSpacing: '1.2px',
                          border: `1px solid ${c.borderBright}`,
                        }}>
                          {display.frame}
                        </div>
                        <h3 style={{
                          fontSize: '42px',
                          fontWeight: 400,
                          margin: '0 0 12px',
                          letterSpacing: '1px',
                          color: c.goldLight,
                        }}>
                          {display.name}
                        </h3>
                        <div style={{
                          fontSize: '18px',
                          color: c.textSec,
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          fontFamily: '"Inter", sans-serif',
                        }}>
                          <span style={{ color: c.gold }}>📍</span> {display.location}
                        </div>
                      </div>
                      <button style={{
                        padding: '14px 28px',
                        background: `linear-gradient(135deg, rgba(212, 175, 55, 0.25), rgba(212, 175, 55, 0.15))`,
                        border: `1px solid ${c.gold}`,
                        borderRadius: '14px',
                        color: c.gold,
                        fontSize: '14px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        transition: 'all 0.3s',
                        fontFamily: '"Inter", sans-serif',
                        letterSpacing: '0.5px',
                      }}>
                        <I.QR /> Share
                      </button>
                    </div>

                    {display.story && (
                      <p style={{
                        fontSize: '19px',
                        color: c.textSec,
                        lineHeight: 1.8,
                        margin: '0 0 32px',
                        fontStyle: 'italic',
                        borderLeft: `3px solid ${c.gold}`,
                        paddingLeft: '24px',
                      }}>
                        "{display.story}"
                      </p>
                    )}

                    <div style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
                      gap: '16px',
                      paddingTop: '32px',
                      borderTop: `1px solid ${c.border}`,
                    }}>
                      {display.coins.map(coin => (
                        <div
                          key={coin.id}
                          style={{
                            padding: '24px',
                            background: `linear-gradient(135deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01))`,
                            borderRadius: '20px',
                            border: `1px solid ${c.border}`,
                            transition: 'all 0.3s',
                            cursor: 'pointer',
                          }}
                          onMouseEnter={e => {
                            e.currentTarget.style.background = `linear-gradient(135deg, rgba(212, 175, 55, 0.15), rgba(212, 175, 55, 0.05))`;
                            e.currentTarget.style.borderColor = c.borderBright;
                            e.currentTarget.style.transform = 'translateY(-2px)';
                          }}
                          onMouseLeave={e => {
                            e.currentTarget.style.background = 'linear-gradient(135deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01))';
                            e.currentTarget.style.borderColor = c.border;
                            e.currentTarget.style.transform = 'translateY(0)';
                          }}
                        >
                          <div style={{ fontSize: '20px', fontWeight: 600, marginBottom: '8px', color: c.gold }}>
                            {coin.year}
                          </div>
                          <div style={{ fontSize: '13px', color: c.textSec, fontFamily: '"Inter", sans-serif' }}>
                            {coin.grade}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {MY_DISPLAYS.length > 0 && (
              <div style={{
                marginTop: '56px',
                padding: '56px',
                background: `
                  linear-gradient(135deg, rgba(212, 175, 55, 0.15), rgba(212, 175, 55, 0.05)),
                  radial-gradient(circle at 50% 50%, rgba(212, 175, 55, 0.08), transparent 70%)
                `,
                borderRadius: '28px',
                textAlign: 'center',
                border: `1px solid ${c.borderBright}`,
                position: 'relative',
                overflow: 'hidden',
              }}>
                <div style={{
                  position: 'absolute',
                  top: '-100px',
                  right: '-100px',
                  width: '400px',
                  height: '400px',
                  background: 'radial-gradient(circle, rgba(212, 175, 55, 0.2), transparent 70%)',
                  filter: 'blur(80px)',
                  animation: 'pulse-glow 6s ease-in-out infinite',
                }} />
                <div style={{ position: 'relative', zIndex: 1 }}>
                  <h3 style={{ fontSize: '36px', fontWeight: 400, margin: '0 0 16px', letterSpacing: '1px' }}>
                    Create Another Display
                  </h3>
                  <p style={{ fontSize: '18px', color: c.textSec, margin: '0 0 32px' }}>
                    Expand your gallery with additional frames
                  </p>
                  <button
                    onClick={() => setTab('shop')}
                    style={{
                      padding: '16px 48px',
                      background: `linear-gradient(135deg, ${c.gold}, ${c.goldDark})`,
                      border: 'none',
                      borderRadius: '14px',
                      color: '#000',
                      fontSize: '16px',
                      fontWeight: 700,
                      cursor: 'pointer',
                      boxShadow: `0 8px 32px rgba(212, 175, 55, 0.4), inset 0 1px 2px rgba(255,255,255,0.3)`,
                      fontFamily: '"Inter", sans-serif',
                      letterSpacing: '0.5px',
                      transition: 'all 0.3s',
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.transform = 'translateY(-3px)';
                      e.currentTarget.style.boxShadow = `0 12px 40px rgba(212, 175, 55, 0.5), inset 0 1px 2px rgba(255,255,255,0.3)`;
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = `0 8px 32px rgba(212, 175, 55, 0.4), inset 0 1px 2px rgba(255,255,255,0.3)`;
                    }}
                  >
                    Browse Frames
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* VAULT */}
        {tab === 'vault' && (
          <div style={{ animation: 'fade-in 0.5s ease-out' }}>
            <div style={{ marginBottom: '56px' }}>
              <h2 style={{
                fontSize: '56px',
                fontWeight: 400,
                letterSpacing: '2px',
                margin: '0 0 16px',
                background: `linear-gradient(135deg, ${c.goldLight}, ${c.gold})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}>
                Your Vault
              </h2>
              <p style={{ fontSize: '20px', color: c.textSec, margin: 0 }}>
                {vaultView === 'coins'
                  ? `${COINS.length} coins · Total value $${COINS.reduce((sum, c) => sum + c.value, 0).toLocaleString()}`
                  : `${PRINTS.length} prints · ${PRINTS.filter(p => p.nft).length} NFTs`
                }
              </p>
            </div>

            <div style={{ display: 'flex', gap: '12px', marginBottom: '40px' }}>
              {['coins', 'prints'].map(view => (
                <button
                  key={view}
                  onClick={() => setVaultView(view)}
                  style={{
                    padding: '14px 32px',
                    background: vaultView === view
                      ? `linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(212, 175, 55, 0.1))`
                      : 'rgba(255, 255, 255, 0.02)',
                    border: `1px solid ${vaultView === view ? c.borderBright : c.border}`,
                    borderRadius: '12px',
                    color: vaultView === view ? c.gold : c.textSec,
                    fontSize: '15px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    fontFamily: '"Inter", sans-serif',
                    letterSpacing: '0.5px',
                    transition: 'all 0.3s',
                  }}
                >
                  {view === 'coins' ? '🪙 Coins' : '🖼️ Prints & NFTs'}
                </button>
              ))}
            </div>

            {vaultView === 'coins' && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '28px' }}>
                {COINS.map((coin, idx) => (
                  <div
                    key={coin.id}
                    style={{
                      background: c.card,
                      borderRadius: '24px',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      transition: 'all 0.4s',
                      border: `1px solid ${c.border}`,
                      boxShadow: '0 8px 24px rgba(0, 0, 0, 0.4)',
                      animation: `slide-up 0.6s ease-out ${idx * 0.05}s both`,
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.transform = 'translateY(-6px)';
                      e.currentTarget.style.boxShadow = '0 16px 40px rgba(0, 0, 0, 0.6)';
                      e.currentTarget.style.borderColor = c.borderBright;
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.4)';
                      e.currentTarget.style.borderColor = c.border;
                    }}
                  >
                    <div style={{
                      width: '100%',
                      height: '300px',
                      background: `url(${coin.img}) center/cover`,
                      position: 'relative',
                    }}>
                      <div style={{
                        position: 'absolute',
                        top: '16px',
                        right: '16px',
                        padding: '8px 16px',
                        background: 'rgba(0, 0, 0, 0.85)',
                        backdropFilter: 'blur(10px)',
                        borderRadius: '10px',
                        fontSize: '16px',
                        fontWeight: 700,
                        color: c.gold,
                        border: `1px solid ${c.borderBright}`,
                        fontFamily: '"Inter", sans-serif',
                      }}>
                        ${coin.value.toLocaleString()}
                      </div>
                    </div>

                    <div style={{ padding: '24px' }}>
                      <h3 style={{ fontSize: '20px', fontWeight: 600, margin: '0 0 12px', letterSpacing: '-0.3px' }}>
                        {coin.name}
                      </h3>
                      <div style={{ fontSize: '14px', color: c.textSec, fontFamily: '"Inter", sans-serif' }}>
                        {coin.year} · {coin.mint} · {coin.grade}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {vaultView === 'prints' && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '28px' }}>
                {PRINTS.map((print, idx) => (
                  <div
                    key={print.id}
                    style={{
                      background: c.card,
                      borderRadius: '24px',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      transition: 'all 0.4s',
                      border: `1px solid ${c.border}`,
                      boxShadow: '0 8px 24px rgba(0, 0, 0, 0.4)',
                      animation: `slide-up 0.6s ease-out ${idx * 0.05}s both`,
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.transform = 'translateY(-6px)';
                      e.currentTarget.style.boxShadow = '0 16px 40px rgba(0, 0, 0, 0.6)';
                      e.currentTarget.style.borderColor = c.borderBright;
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.4)';
                      e.currentTarget.style.borderColor = c.border;
                    }}
                  >
                    <div style={{
                      width: '100%',
                      height: '340px',
                      background: `url(${print.img}) center/cover`,
                      position: 'relative',
                    }}>
                      {print.nft && (
                        <div style={{
                          position: 'absolute',
                          top: '16px',
                          right: '16px',
                          padding: '8px 16px',
                          background: 'rgba(0, 0, 0, 0.9)',
                          backdropFilter: 'blur(10px)',
                          borderRadius: '10px',
                          fontSize: '12px',
                          fontWeight: 700,
                          color: c.gold,
                          border: `1px solid ${c.gold}`,
                          fontFamily: '"Inter", sans-serif',
                          letterSpacing: '1px',
                        }}>
                          NFT
                        </div>
                      )}
                    </div>

                    <div style={{ padding: '24px' }}>
                      <h3 style={{ fontSize: '22px', fontWeight: 500, margin: '0 0 8px', letterSpacing: '-0.3px' }}>
                        {print.name}
                      </h3>
                      <div style={{ fontSize: '14px', color: c.textSec, marginBottom: '6px', fontFamily: '"Inter", sans-serif' }}>
                        by {print.artist}
                      </div>
                      <div style={{ fontSize: '13px', color: c.gold, fontWeight: 600, fontFamily: '"Inter", sans-serif' }}>
                        {print.edition}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* SHOP */}
        {tab === 'shop' && (
          <div style={{ animation: 'fade-in 0.5s ease-out' }}>
            <div style={{ marginBottom: '56px' }}>
              <h2 style={{
                fontSize: '56px',
                fontWeight: 400,
                letterSpacing: '2px',
                margin: '0 0 16px',
                background: `linear-gradient(135deg, ${c.goldLight}, ${c.gold})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}>
                Shop
              </h2>
              <p style={{ fontSize: '20px', color: c.textSec, margin: 0 }}>
                Premium frames, prints, and accessories
              </p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '32px', marginBottom: '64px' }}>
              {[
                { title: 'Display Frames', desc: 'Museum-quality frames', img: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&q=80' },
                { title: 'Art Prints & NFTs', desc: 'Limited edition prints', img: 'https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=800&q=80' },
                { title: 'Accessories', desc: 'Premium supplies', img: 'https://images.unsplash.com/photo-1434493651957-4ec9f76d0e1e?w=800&q=80' },
              ].map((cat, idx) => (
                <div
                  key={idx}
                  onClick={openStore}
                  style={{
                    background: c.card,
                    borderRadius: '24px',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    border: `1px solid ${c.border}`,
                    transition: 'all 0.4s',
                    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.4)',
                    animation: `slide-up 0.6s ease-out ${idx * 0.1}s both`,
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.transform = 'translateY(-8px)';
                    e.currentTarget.style.boxShadow = '0 16px 48px rgba(0, 0, 0, 0.6)';
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.4)';
                  }}
                >
                  <div style={{
                    width: '100%',
                    height: '260px',
                    background: `url(${cat.img}) center/cover`,
                  }} />
                  <div style={{ padding: '32px' }}>
                    <h3 style={{ fontSize: '28px', fontWeight: 500, margin: '0 0 12px', letterSpacing: '-0.3px' }}>
                      {cat.title}
                    </h3>
                    <p style={{ fontSize: '16px', color: c.textSec, margin: '0 0 20px', fontFamily: '"Inter", sans-serif' }}>
                      {cat.desc}
                    </p>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      color: c.gold,
                      fontSize: '15px',
                      fontWeight: 600,
                      fontFamily: '"Inter", sans-serif',
                    }}>
                      Explore <I.External />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div style={{
              background: `
                linear-gradient(135deg, rgba(212, 175, 55, 0.15), rgba(212, 175, 55, 0.05)),
                radial-gradient(circle at 50% 0%, rgba(212, 175, 55, 0.1), transparent 70%)
              `,
              borderRadius: '28px',
              padding: '64px',
              textAlign: 'center',
              border: `1px solid ${c.borderBright}`,
            }}>
              <I.Sparkles />
              <h3 style={{ fontSize: '40px', fontWeight: 400, margin: '24px 0 16px', letterSpacing: '1px' }}>
                Visit Our Store
              </h3>
              <p style={{ fontSize: '19px', color: c.textSec, margin: '0 0 40px', maxWidth: '640px', marginLeft: 'auto', marginRight: 'auto' }}>
                Explore our full collection of display frames, limited edition prints, and premium accessories
              </p>
              <button
                onClick={openStore}
                style={{
                  padding: '18px 52px',
                  background: `linear-gradient(135deg, ${c.gold}, ${c.goldDark})`,
                  border: 'none',
                  borderRadius: '14px',
                  color: '#000',
                  fontSize: '17px',
                  fontWeight: 700,
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '12px',
                  boxShadow: `0 8px 32px rgba(212, 175, 55, 0.4), inset 0 1px 2px rgba(255,255,255,0.3)`,
                  fontFamily: '"Inter", sans-serif',
                  letterSpacing: '0.5px',
                  transition: 'all 0.3s',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = 'translateY(-3px)';
                  e.currentTarget.style.boxShadow = `0 12px 40px rgba(212, 175, 55, 0.5), inset 0 1px 2px rgba(255,255,255,0.3)`;
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = `0 8px 32px rgba(212, 175, 55, 0.4), inset 0 1px 2px rgba(255,255,255,0.3)`;
                }}
              >
                Open Store <I.External />
              </button>
            </div>
          </div>
        )}

        {/* HELP & DISCOVER */}
        {tab === 'help' && (
          <div style={{ animation: 'fade-in 0.5s ease-out' }}>
            <div style={{ marginBottom: '56px' }}>
              <h2 style={{
                fontSize: '56px',
                fontWeight: 400,
                letterSpacing: '2px',
                margin: '0 0 16px',
                background: `linear-gradient(135deg, ${c.goldLight}, ${c.gold})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}>
                Help & Discover
              </h2>
              <p style={{ fontSize: '20px', color: c.textSec, margin: 0 }}>
                Support, sharing, and community
              </p>
            </div>

            <div style={{
              background: c.card,
              borderRadius: '24px',
              padding: '40px',
              marginBottom: '40px',
              border: `1px solid ${c.border}`,
              boxShadow: '0 8px 24px rgba(0, 0, 0, 0.3)',
            }}>
              <div style={{ display: 'flex', gap: '28px', alignItems: 'center', marginBottom: '36px' }}>
                <div style={{
                  width: '88px',
                  height: '88px',
                  borderRadius: '50%',
                  background: `linear-gradient(135deg, ${c.gold}, ${c.goldDark})`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '36px',
                  flexShrink: 0,
                  boxShadow: `0 8px 24px rgba(212, 175, 55, 0.3)`,
                }}>
                  👤
                </div>
                <div>
                  <h3 style={{ fontSize: '28px', fontWeight: 500, margin: '0 0 6px', letterSpacing: '-0.5px' }}>
                    Sarah Mitchell
                  </h3>
                  <div style={{ fontSize: '16px', color: c.textSec, fontFamily: '"Inter", sans-serif' }}>
                    Your Display Specialist
                  </div>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
                <button style={{
                  padding: '18px',
                  background: `linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(212, 175, 55, 0.1))`,
                  border: `1px solid ${c.borderBright}`,
                  borderRadius: '14px',
                  color: c.gold,
                  fontSize: '15px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '10px',
                  fontFamily: '"Inter", sans-serif',
                  letterSpacing: '0.3px',
                  transition: 'all 0.3s',
                }}>
                  <I.Phone /> Request Call
                </button>
                <button style={{
                  padding: '18px',
                  background: 'rgba(255, 255, 255, 0.03)',
                  border: `1px solid ${c.border}`,
                  borderRadius: '14px',
                  color: c.text,
                  fontSize: '15px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '10px',
                  fontFamily: '"Inter", sans-serif',
                  letterSpacing: '0.3px',
                  transition: 'all 0.3s',
                }}>
                  <I.Link /> Message
                </button>
              </div>
            </div>

            <div>
              <h3 style={{ fontSize: '32px', fontWeight: 400, margin: '0 0 28px', letterSpacing: '1px' }}>
                Discover & Share
              </h3>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '24px' }}>
                {[
                  { icon: '🔗', title: 'Share with Friends & Family', desc: 'Generate secure links for your displays' },
                  { icon: '🌟', title: 'Featured Collections', desc: 'Curated displays from top collectors' },
                  { icon: '📚', title: 'Learning Center', desc: 'Guides and tips for collectors' },
                  { icon: '🎨', title: 'Artist Showcase', desc: 'Discover limited edition prints' },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    style={{
                      padding: '32px',
                      background: c.card,
                      borderRadius: '20px',
                      border: `1px solid ${c.border}`,
                      cursor: 'pointer',
                      transition: 'all 0.3s',
                      animation: `slide-up 0.5s ease-out ${idx * 0.08}s both`,
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.background = c.cardHover;
                      e.currentTarget.style.borderColor = c.borderBright;
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.background = c.card;
                      e.currentTarget.style.borderColor = c.border;
                    }}
                  >
                    <div style={{ fontSize: '40px', marginBottom: '16px' }}>{item.icon}</div>
                    <h4 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 10px', letterSpacing: '-0.3px' }}>
                      {item.title}
                    </h4>
                    <p style={{ fontSize: '14px', color: c.textSec, margin: 0, fontFamily: '"Inter", sans-serif', lineHeight: 1.6 }}>
                      {item.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* GAP FINDER */}
        {tab === 'hunt' && (
          <div style={{ animation: 'fade-in 0.5s ease-out' }}>
            <div style={{ marginBottom: '56px' }}>
              <h2 style={{
                fontSize: '56px',
                fontWeight: 400,
                letterSpacing: '2px',
                margin: '0 0 16px',
                background: `linear-gradient(135deg, ${c.goldLight}, ${c.gold})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}>
                Gap Finder
              </h2>
              <p style={{ fontSize: '20px', color: c.textSec, margin: 0 }}>
                Track missing coins and connect with dealers
              </p>
            </div>

            <div style={{
              background: `linear-gradient(135deg, rgba(212, 175, 55, 0.12), rgba(212, 175, 55, 0.04))`,
              borderRadius: '24px',
              padding: '40px',
              marginBottom: '40px',
              border: `1px solid ${c.borderBright}`,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                <I.Compass />
                <h3 style={{ fontSize: '28px', fontWeight: 500, margin: 0, letterSpacing: '-0.5px' }}>
                  Need Help Finding Coins?
                </h3>
              </div>
              <p style={{ fontSize: '17px', color: c.textSec, margin: '0 0 32px', lineHeight: 1.7, fontFamily: '"Inter", sans-serif' }}>
                Our partner dealers can help you locate rare and missing pieces
              </p>

              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
                <button style={{
                  padding: '14px 32px',
                  background: `linear-gradient(135deg, ${c.gold}, ${c.goldDark})`,
                  border: 'none',
                  borderRadius: '12px',
                  color: '#000',
                  fontSize: '15px',
                  fontWeight: 700,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  fontFamily: '"Inter", sans-serif',
                  letterSpacing: '0.3px',
                  boxShadow: `0 6px 20px rgba(212, 175, 55, 0.3)`,
                }}>
                  <I.Phone /> Call (555) 123-4567
                </button>

                <button style={{
                  padding: '14px 32px',
                  background: 'rgba(255, 255, 255, 0.05)',
                  border: `1px solid ${c.border}`,
                  borderRadius: '12px',
                  color: c.text,
                  fontSize: '15px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  fontFamily: '"Inter", sans-serif',
                  letterSpacing: '0.3px',
                }}>
                  <I.Location /> Find Nearby Dealer
                </button>

                <button
                  onClick={() => window.open('https://numivas.com/dealers', '_blank')}
                  style={{
                    padding: '14px 32px',
                    background: 'rgba(255, 255, 255, 0.05)',
                    border: `1px solid ${c.border}`,
                    borderRadius: '12px',
                    color: c.text,
                    fontSize: '15px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    fontFamily: '"Inter", sans-serif',
                    letterSpacing: '0.3px',
                  }}
                >
                  <I.External /> Browse Partners
                </button>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {gapAlerts.map((alert, idx) => (
                <div
                  key={idx}
                  style={{
                    background: c.card,
                    borderRadius: '20px',
                    padding: '32px',
                    border: `1px solid ${c.border}`,
                    animation: `slide-up 0.5s ease-out ${idx * 0.1}s both`,
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                    <h3 style={{ fontSize: '22px', fontWeight: 500, margin: 0, letterSpacing: '-0.3px' }}>
                      {alert.series}
                    </h3>
                    <button
                      onClick={() => toggleAlert(idx)}
                      style={{
                        padding: '10px 20px',
                        background: alert.alertOn ? `rgba(212, 175, 55, 0.2)` : 'rgba(255, 255, 255, 0.03)',
                        border: `1px solid ${alert.alertOn ? c.gold : c.border}`,
                        borderRadius: '24px',
                        color: alert.alertOn ? c.gold : c.textSec,
                        fontSize: '13px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        fontFamily: '"Inter", sans-serif',
                        letterSpacing: '0.3px',
                      }}
                    >
                      <I.Bell /> {alert.alertOn ? 'Alerts On' : 'Alerts Off'}
                    </button>
                  </div>

                  <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1.5px', color: c.textSec, fontWeight: 600, marginBottom: '16px', fontFamily: '"Inter", sans-serif' }}>
                    Missing from Collection
                  </div>

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
                    {alert.missing.map((coin, i) => (
                      <div
                        key={i}
                        style={{
                          padding: '10px 18px',
                          background: 'rgba(255, 255, 255, 0.02)',
                          border: `1px solid ${c.border}`,
                          borderRadius: '10px',
                          fontSize: '14px',
                          fontWeight: 500,
                          fontFamily: '"Inter", sans-serif',
                        }}
                      >
                        {coin}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Inter:wght@400;500;600;700;800&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        button { font-family: inherit; }
        button:active { transform: scale(0.98); }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: #0a0a0a; }
        ::-webkit-scrollbar-thumb { background: rgba(212, 175, 55, 0.3); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(212, 175, 55, 0.5); }
        
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slide-up {
          from { 
            opacity: 0; 
            transform: translateY(30px);
          }
          to { 
            opacity: 1; 
            transform: translateY(0);
          }
        }
        
        @keyframes gentle-float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-6px); }
        }
        
        @keyframes pulse-glow {
          0%, 100% { opacity: 0.6; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}
