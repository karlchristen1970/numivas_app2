# Numivas - Luxury Coin Gallery

A beautifully designed React application for managing and showcasing coin collections with museum-quality display frames.

## ✨ Features

- **Displays**: Create and manage stunning visual displays of your coin collection
- **Vault**: Track coins and art prints/NFTs in your collection
- **Shop**: Browse display frames and accessories
- **Help & Discover**: Connect with specialists and the collector community
- **Gap Finder**: Track missing coins with dealer referral system

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Local Development

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Start development server**
   ```bash
   npm run dev
   ```

3. **Open in browser**
   - Navigate to `http://localhost:5173`

### Build for Production

```bash
npm run build
```

The optimized production build will be in the `dist/` directory.

## 📦 Deploy to Netlify

### Option 1: Deploy via Netlify CLI

1. **Install Netlify CLI**
   ```bash
   npm install -g netlify-cli
   ```

2. **Login to Netlify**
   ```bash
   netlify login
   ```

3. **Deploy**
   ```bash
   netlify deploy --prod
   ```

### Option 2: Deploy via GitHub + Netlify Dashboard

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/numivas-gallery.git
   git push -u origin main
   ```

2. **Connect to Netlify**
   - Go to [Netlify](https://app.netlify.com)
   - Click "Add new site" → "Import an existing project"
   - Connect your GitHub repository
   - Configure build settings:
     - **Build command**: `npm run build`
     - **Publish directory**: `dist`
   - Click "Deploy site"

### Option 3: Drag & Drop Deploy

1. **Build the project**
   ```bash
   npm run build
   ```

2. **Deploy to Netlify**
   - Go to [Netlify Drop](https://app.netlify.com/drop)
   - Drag the `dist` folder to the upload area
   - Your site will be live instantly!

## 🎨 Design Aesthetic

This app features a **luxury museum** aesthetic with:
- Elegant serif typography (Cormorant Garamond)
- Rich gold color palette (#d4af37)
- Sophisticated animations and transitions
- Premium depth and shadow effects
- Museum-quality presentation

## 🛠️ Tech Stack

- **React 18** - UI framework
- **Vite** - Build tool and dev server
- **CSS-in-JS** - Inline styled components
- **Google Fonts** - Cormorant Garamond & Inter

## 📁 Project Structure

```
numivas-gallery/
├── src/
│   ├── App.jsx          # Main application component
│   ├── main.jsx         # React entry point
│   └── index.css        # Global styles
├── index.html           # HTML template
├── package.json         # Dependencies and scripts
├── vite.config.js       # Vite configuration
├── netlify.toml         # Netlify deployment config
└── README.md            # This file
```

## 🔧 Configuration

The app is configured with:
- **Vite** for fast development and optimized builds
- **Netlify** for seamless deployment with SPA routing
- **React** for component-based UI

## 📝 Notes

- All images use Unsplash URLs - replace with your own hosted images for production
- The app is fully responsive and works on all devices
- Animations are CSS-only for optimal performance

## 🤝 Support

For questions or issues, please contact your Numivas specialist.

---

**Built with ❤️ for coin collectors**
