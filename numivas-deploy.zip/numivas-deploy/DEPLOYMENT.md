# 🚀 Quick Deployment Guide

## Fastest Way: Netlify Drop (No GitHub Required)

1. **Build the project**
   ```bash
   npm install
   npm run build
   ```

2. **Deploy**
   - Go to https://app.netlify.com/drop
   - Drag the `dist` folder into the upload area
   - Done! Your site is live

---

## GitHub + Netlify (Recommended for Updates)

### Step 1: Create GitHub Repository

1. Go to https://github.com/new
2. Name it: `numivas-gallery`
3. Don't initialize with README (we already have one)
4. Click "Create repository"

### Step 2: Push Code to GitHub

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Numivas luxury gallery"

# Set main branch
git branch -M main

# Add your GitHub repo (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/numivas-gallery.git

# Push to GitHub
git push -u origin main
```

### Step 3: Deploy on Netlify

1. Go to https://app.netlify.com
2. Click **"Add new site"** → **"Import an existing project"**
3. Choose **"GitHub"**
4. Select your `numivas-gallery` repository
5. Configure build settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
6. Click **"Deploy site"**

That's it! Netlify will:
- Build your site
- Deploy it to a URL like `https://your-site-name.netlify.app`
- Auto-deploy on every GitHub push

### Step 4: Custom Domain (Optional)

1. In Netlify dashboard, go to **"Domain settings"**
2. Click **"Add custom domain"**
3. Follow instructions to connect your domain

---

## Netlify CLI (For Advanced Users)

```bash
# Install Netlify CLI globally
npm install -g netlify-cli

# Login to Netlify
netlify login

# Initialize site (first time only)
netlify init

# Deploy to production
netlify deploy --prod
```

---

## Updating Your Site

### If using GitHub + Netlify:
```bash
git add .
git commit -m "Your update message"
git push
```
Netlify auto-deploys!

### If using Netlify Drop:
```bash
npm run build
```
Then drag the new `dist` folder to https://app.netlify.com/drop

---

## Troubleshooting

### "Command not found: npm"
Install Node.js from https://nodejs.org

### Build fails on Netlify
- Check that Node version is 18+ in Netlify settings
- Verify `package.json` dependencies are correct

### Site shows blank page
- Check browser console for errors
- Ensure `netlify.toml` redirects are configured
- Clear cache and hard reload (Ctrl+Shift+R)

---

## Need Help?

- Netlify Docs: https://docs.netlify.com
- Vite Docs: https://vitejs.dev
- React Docs: https://react.dev
